console.log('hello');
const form = document.querySelector('form');
const API_URL = window.location.hostname === 'localhost' ? 'http://localhost/quotes' : 'https:/web-programming.project';

listAllQuotes();
form.addEventListener('submit', (event) => {
    event.preventDefault();
    const formData = new FormData(form);
    const name = formData.get('name');
    const company = formData.get('company');
    const email = formData.get('email');
    const phone = formData.get('phone');
    const dWork = formData.get('dWork');
    // Input object will move here
    const quote = {
        name,
        company,
        email,
        phone,
        dWork
    };
    console.log(quote);
    // sending data to backend server
    fetch(API_URL, {
            method: 'POST',
            body: JSON.stringify(quote),
            headers: {
                'content-type': 'application/json'
            }

        })
        .then(response => response.json())
        .then(createdQuote => {
            form.reset();
            setTimeout(() => {
                form.style.display = '';
            }, 60000);
            listAllQuotes();

        });
});

function listAllQuotes() {
    fetch(API_URL)
        .then(response => response.json())
        .then(quotes => {
            console.log(quotes);

        });
}