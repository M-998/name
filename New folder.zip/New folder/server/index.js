const express = require('express');
const cors = require('cors');
const monk = require('monk');

//express library and app
const app = express();
//db
const db = monk('localhost/mongodb+srv://user:123@cluster0-16lq7.mongodb.ne/ITE-410');


const quotes = db.get('quotes');

app.use(cors());
app.use(express.json());

//get request
app.get('/quotes', (req, res) => {

    quotes
        .find()
        .then(quotes => {
            res.json(quotes);
        });



});

function isValidQuote(quote) {
    return quote.name && quote.name.toString().trim() !== '' &&
        quote.company && quote.company.toString().trim() !== '' &&
        quote.email && quote.email.toString().trim() !== '' &&
        quote.phone && quote.phone.toString().trim() !== '' &&
        quote.dWork && quote.dWork.toString().trim() !== '';
}

//post
app.post('/quotes', (req, res) => {
    if (isValidQuote(req.body)) {
        //insert to database
        const quote = {
            name: req.body.name.toString(),
            company: req.body.company.toString(),
            email: req.body.email.toString(),
            phone: req.body.phone.toString(),
            email: req.body.dWork.toString()
        };


        quotes
            .insert(quote)
            .then(createdQuote => {
                res.json(createdQuote);
            });

    } else {
        res.status(422);
        res.json({
            message: 'Form cannot be empty'
        });
    }

    ;
});

app.listen(5000, () => {
    console.log('Listening to http://localhost:5000/quotes');
});